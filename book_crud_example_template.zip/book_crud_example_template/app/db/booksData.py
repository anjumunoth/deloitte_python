from typing import List
from app.models.bookModel import Books
from app.models.userModels import Users
from datetime import date

books: List[Books] = [
    Books(
        title="Clean Code",
        authors=[Users(name="Robert C. Martin", email="unclebob@example.com")],
        price=500,
        inStock=True,
        dateOfPublication=date(2008, 8, 1),
        genre="non-fiction",
        isbn="9780132350884"
    ),
    Books(
        title="Fluent Python",
        authors=[Users(name="Luciano Ramalho", email="luciano@example.com")],
        price=750,
        inStock=True,
        dateOfPublication=date(2015, 8, 20),
        genre="science",
        isbn="9781491946008"
    ),
    Books(
        title="Designing Data-Intensive Applications",
        authors=[Users(name="Martin Kleppmann", email="martin@example.com")],
        price=900,
        inStock=False,
        dateOfPublication=date(2017, 3, 16),
        genre="non-fiction",
        isbn="9781449373320"
    )
]

from fastapi import FastAPI

from app.routers import books as booksRouter


app = FastAPI()


app.include_router(booksRouter.router, prefix="/books", tags=["books"])

@app.get("/")
async def read_root():
    return {"message":"Welcome to books crud api"}   
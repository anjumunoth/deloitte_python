from fastapi import FastAPI, HTTPException
from typing import Annotated, List, Literal
from fastapi.params import Body, Path,Query
from enum import Enum
from datetime import date

from pydantic import BaseModel, Field,field_validator,model_validator

class Users(BaseModel):
    name:str
    email:str
    # @model_validator(mode="after")
    # def validate_email(values):
    #     #name should be there in the email id before @
    #     print(values)
    #     name= values['name']
    #     v= values['email']
    #     if name and name.replace(" ","").lower() not in v.split("@")[0].lower():
    #         raise ValueError("Email id should contain the name of the user" )
    #     return values

from fastapi import APIRouter

from typing import List
from app.db.booksData import books

router = APIRouter(
    prefix="/books",
    tags=["books"],
    responses={404: {"description": "Not found"}},
)

@router.get("/")
def get_books():
    return books






from pydantic import BaseModel, constr

class UserCreate(BaseModel):
    username: str
    password: constr(min_length=8, max_length=72) # type: ignore


class TaskCreate(BaseModel):
    title: str

class TaskResponse(BaseModel):
    id: int
    title: str
    completed: bool
    owner_id: int

    class Config:
        orm_mode = True
from pydantic_settings import BaseSettings, SettingsConfigDict
import os

class Settings(BaseSettings):
    DATABASE_URL: str
    model_config=SettingsConfigDict(
        env_file=os.path.join(os.path.dirname(__file__), '..', '..', '.env'),
        env_file_encoding="utf-8",  
        extra="ignore"
    )

settings = Settings()


#C:\Users\Anju Munoth\Desktop\deloitte\book_crud_example\app\core -- windows path
#Mac -- /Users/anjumunoth/Desktop/deloitte/book_crud_example/app/core


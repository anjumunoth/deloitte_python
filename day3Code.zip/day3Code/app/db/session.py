

from sqlalchemy import create_engine
from sqlalchemy.orm  import sessionmaker
from app.core.config import settings

engine=create_engine(settings.DATABASE_URL, connect_args={"check_same_thread": False})
sessionLocal= sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    #generator function to get db session
    # to get the session use: db: Session=Depends(get_db)
    # DI function
    # logic to create session and close session
    # yield keyword to return session object
    # execute the code where dependency has been injected
    # after execution of that code(), the code after yield will be executed -- finally block
    # close the db session
    # if the dependency has been added as part of path operation function, then for every request a new session will be created and closed(after the response has been sent). 
    # should be global dependency -- should be used only for a particular request -- each request should have its own session
    
    db=sessionLocal()
    try:
        yield db
    finally:
        db.close()
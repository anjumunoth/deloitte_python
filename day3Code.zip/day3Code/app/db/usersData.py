import pydantic
from typing import List
import datetime

from app.models.userModels import Users

registeredUsers: List[Users] = [
    Users(name="John", email="johnDoe@gmail.com"),
    Users(name="Jane", email="janeSmith@gmail.com"),
    Users(name="Alice", email="aliceJohnson@gmail.com")]

from fastapi import HTTPException
from app.models.bookModel import GenreCategory
from datetime import date

def validate_isbn(isbn: str) -> str:
    if len(isbn) < 10 or len(isbn) > 13:
        raise HTTPException(status_code=400, detail="ISBN must be between 10 and 13 characters")
    return isbn


def validate_genre(genre: str) -> str:
    valid_genres = GenreCategory._member_names_
    print(valid_genres)
    if genre.lower() not in valid_genres:
        raise HTTPException(status_code=400, detail=f"Genre must be one of {', '.join(valid_genres)}")
    return genre

class FilterParamClass:
    def __init__(self, price: int | None = None,author: str | None = None,dateOfPublication: date | None = None):
        if price is not None and price <= 0:
            raise HTTPException(status_code=400, detail="Price must be greater than 0")
        self.price = price
        self.author = author
        self.dateOfPublication = dateOfPublication

#sortField: str = Query(..., description="Field to sort by (any Books attribute)"),
class SortFieldParamClass:
    def __call__(self, sortField: str|None = None) -> str|None:
        self.sortField = sortField
        return self.sortField

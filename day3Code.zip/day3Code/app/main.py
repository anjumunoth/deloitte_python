from fastapi import FastAPI

from app.routers import books as booksRouter
from app.routers import sample as sampleRouter
from app.routers import auth as authRouter
from app.routers import diExample as diExampleRouter

app = FastAPI()

app.include_router(authRouter.router, prefix="/auth", tags=["auth"])
app.include_router(booksRouter.router, prefix="/books", tags=["books"])
app.include_router(sampleRouter.router, prefix="/sample", tags=["sample"])
app.include_router(diExampleRouter.router, prefix="/diExample", tags=["diExample"])

@app.get("/")
async def read_root():
    return {"message":"Welcome to books crud api"}   
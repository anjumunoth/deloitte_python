from fastapi import APIRouter, HTTPException,Form
from fastapi.responses import HTMLResponse
from fastapi.responses import FileResponse, StreamingResponse, RedirectResponse, Response
from fastapi.requests import Request
from fastapi.templating import Jinja2Templates
from pathlib import Path 

    

router= APIRouter(
    tags=["sample"],    
    responses={404: {"description":"Not found"}},
)

Base_dir=Path(__file__).parent.parent
templates=Jinja2Templates(directory=Base_dir / "templates")
        
@router.get("/register")
def register_user(request:Request):
    print(f"Request object: {request}")

    #load the register.html file
    try:
        return templates.TemplateResponse("register.html", {"request": request})

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="HTML file not found")
    
@router.post("/register")
def register_user_post(request:Request,
                       name:str=Form(...),
                       email:str=Form(...),
                       password:str=Form(...),
                       confirm_password:str=Form(...)
                       ):
    # data is coming in form of request object form data
    #1. validate the form data
    #2. persist the data in db or in memory
    #3. if all ok redirect to login page else show error message on same page
    errors=[]
    if password != confirm_password:
        errors.append("Password and Confirm password do not match")
        return templates.TemplateResponse("register.html", {"request": request, "errors": errors})
    #validate if the email is already registered
    #persist the user data
    return RedirectResponse(url="/auth/login", status_code=303)


@router.get("/login")
def login_user(request:Request):
    #load the login.html file
    try:
        return templates.TemplateResponse("login.html", {"request": request})

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="HTML file not found")

    
@router.post("/login")
def login_user_post(
    request: Request, email: str = Form(...), password: str = Form(...,min_length=8, max_length=20)
):

    errors = []
    # 2. validate against DB
    # 3. generate token
    response = RedirectResponse(url="/books", status_code=303)
    return response
    
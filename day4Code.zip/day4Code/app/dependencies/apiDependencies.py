from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, SecurityScopes
from sqlalchemy.orm import Session
from app.models.userModels import User
from app.db.session import get_db
from jose import jwt
from app.core.config import settings
from app.models.token import TokenData

oauth2_scheme=OAuth2PasswordBearer(
    tokenUrl="/auth/login",
    scopes={
        "me":"Read information about the current user",
        "items:read":" Read items",
        "items:write":"Create and modify the items",
        "users:read":"Read all the user information"
    }
)

def get_current_user(
        user_scopes:SecurityScopes,
        token:str=Depends(oauth2_scheme),
        db:Session=Depends(get_db  )     
):
    if user_scopes.scopes:
        authenticate_value=f'Bearer scope="{user_scopes.scope_str}"'
    else:
        authenticate_value=f'Bearer'

    payload=jwt.decode(token, settings.SECRET_KEY,algorithms=settings.ALGORITHM)
    username:str=payload.get("sub")
    if not username:
        raise HTTPException(status_code=401,detail="Could not validate the credentials",headers={"WWW-Authenticate":authenticate_value})
    token_scopes=payload.get("scopes")
    token_data=TokenData(user_name=username,scopes=token_scopes)
    #user is authorised or not 
    for scope in user_scopes.scopes:
        if scope not in token_scopes:
            raise HTTPException(status_code=401,detail="Not enough permissions",headers={"WWW-Authenticate":authenticate_value})
        
    user=db.query(User).filter(User.email == username).first()
    if user is None:
            raise HTTPException(status_code=401,detail="User not validated",headers={"WWW-Authenticate":authenticate_value})
    return user

        






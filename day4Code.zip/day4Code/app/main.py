import time
from fastapi import FastAPI, Request,Response,HTTPException

from app.routers import items as itemsRouter
from app.routers import books as booksRouter
from app.routers import sample as sampleRouter
from app.routers import auth as authRouter
from app.routers import diExample as diExampleRouter
from app.db.base import Base
from app.db.session import engine
import logging
from app.middlewares.customMiddlewares import RequestValidationMiddleware


logging.basicConfig(level=logging.INFO)
logger=logging.getLogger(__name__)

app = FastAPI()

Base.metadata.create_all(bind=engine)

#add middleware
# app.add_middleware(RequestValidationMiddleware)

@app.middleware("http")
async def loggingInConsole(request:Request,call_next):
    print(f"ReQuest object url :{request.url},method : {request.method}")
    if request.method == "PATCH":
        raise HTTPException(status_code=405, detail="PATCH not allowed")
    response:Response =await call_next(request)
    print(f"Response details  : {response.status_code}")
    return response


#logging for process time
@app.middleware("http")
async def calculate_request_response_time(request:Request,call_next):
    logger.info(f"Request started : :{request.url},method : {request.method}")
    start_time=time.time()
    #write into file
    
    response:Response =await call_next(request)
    process_time= time.time()-start_time
    logger.info(f"Request completed : :{request.url},method : {request.method},status_code :{response.status_code}, process_time: {process_time}")
    return response

# order of execution --calculate process time; logging   ; request validation
app.include_router(itemsRouter.router,prefix="/items",tags=["items"])
app.include_router(authRouter.router, prefix="/auth", tags=["auth"])
app.include_router(booksRouter.router, prefix="/books", tags=["books"])
app.include_router(sampleRouter.router, prefix="/sample", tags=["sample"])
app.include_router(diExampleRouter.router, prefix="/diExample", tags=["diExample"])



@app.get("/")
async def read_root():
    return {"message":"Welcome to books crud api"}   
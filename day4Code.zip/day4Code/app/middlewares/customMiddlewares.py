from fastapi import FastAPI, Request,Response,HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

class RequestValidationMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request:Request,call_next):
        # code to run before the route handler
        # check if the bearer token is there or not
        # bearer token will not be there in register(all methods), login(get and post)
        # localhost:8000/auth/login
        checkurls=[
            f"{request.base_url}auth/login",
            f"{request.base_url}auth/register",
        ]
        print("CheckUrls",checkurls)
        print("request url",request.url)
        if not request.url in checkurls:
            if "Authorisation_token" not in request.headers:
                raise JSONResponse(status_code=400,detail="Authorisation token required")

        response:Response =await call_next(request)
        # code to run after the route handler
        return response



from fastapi import FastAPI, HTTPException
from typing import Annotated, List, Literal
from fastapi.params import Body, Path,Query
from enum import Enum
from datetime import date
from app.models.userModels import Users
from app.db.usersData import registeredUsers
from pydantic import BaseModel, Field,field_validator,model_validator

class IsbnSchema(BaseModel):
    isbn: str = Field(..., min_length=10, max_length=13)
class GenreCategory(str,Enum):
    fiction = "fiction"
    nonfiction = "non-fiction"
    science = "science"
    biography="biography"
    history = "history"
    fantasy="fantasy"

today=date.today()
class Books(IsbnSchema):
    title: str
    authors: List[Users]
    price:int= Field(..., gt=0)
    inStock: bool = True    
    dateOfPublication: date|None=Field(...,lt=today)
    genre: GenreCategory=GenreCategory.fiction
    @field_validator('authors')
    def validate_authors(cls, v):
        if not v:
            raise ValueError('At least one author is required')
        for author in v:
            if not len(author.name)>0 or not len(author.email)>0:
                # [{name:"",email:""}] should raise error
                raise ValueError('Each author must have a non empty name and non empty email')
            # userexists =  [user for user in registeredUsers if user.name.lower() == author.name.lower()]
            # if not userexists:
            #     raise ValueError('Author is not a registered user')
        return v    


from fastapi import FastAPI, HTTPException
from typing import Annotated, List, Literal
from fastapi.params import Body, Path,Query
from enum import Enum
from datetime import date

from pydantic import BaseModel, EmailStr, Field,field_validator,model_validator
from sqlalchemy import Column, Integer, String

from app.db.base import Base

class Users(BaseModel):
    name:str
    email:str
    @model_validator(mode="after")
    def email_must_contain_name(self):
        if self.name.lower() not in self.email.lower():
            raise ValueError("Email must contain the name")
        return self

    # @model_validator(mode="after")
    # def validate_email(values):
    #     #name should be there in the email id before @
    #     print(values)
    #     name= values['name']
    #     v= values['email']
    #     if name and name.replace(" ","").lower() not in v.split("@")[0].lower():
    #         raise ValueError("Email id should contain the name of the user" )
    #     return values

class User(Base):
    __tablename__="users"
    id=Column(Integer,primary_key=True, index=True)
    name=Column(String)
    email=Column(String, unique=True)
    hashed_password=Column(String)
    role=Column(String,default="guest")# admin,user,guest


class UserBase(BaseModel):
    email:EmailStr

class UserCreate(UserBase):
    password:str
    role:str = "guest" 

class UserResponse(UserBase):
    id:int
    role:str = "guest" 
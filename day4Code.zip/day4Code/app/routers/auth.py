from fastapi import APIRouter, Depends, HTTPException,Form
from fastapi.responses import HTMLResponse
from fastapi.responses import FileResponse, StreamingResponse, RedirectResponse, Response
from fastapi.requests import Request
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.templating import Jinja2Templates
from pathlib import Path
from sqlalchemy.orm import Session

from app.core.security import get_password_hash, verify_password
from app.db.session import get_db
from app.models.userModels import User 
from app.core.security import get_scopes_for_role,create_access_token

    

router= APIRouter(
    tags=["sample"],    
    responses={404: {"description":"Not found"}},
)

Base_dir=Path(__file__).parent.parent
templates=Jinja2Templates(directory=Base_dir / "templates")
        
@router.get("/register")
def register_user(request:Request):
    print(f"Request object: {request}")

    #load the register.html file
    try:
        return templates.TemplateResponse("register.html", {"request": request})

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="HTML file not found")
    
@router.post("/register")
def register_user_post(
                       request:Request,
                       name:str=Form(...),
                       email:str=Form(...),
                       password: str = Form(...,min_length=8, max_length=20),
                       confirm_password:str=Form(...),
                       role:str=Form("guest"),
                       db:Session=Depends(get_db),
                       ):
    # data is coming in form of request object form data
    #1. validate the form data
    #2. persist the data in db or in memory
    #3. if all ok redirect to login page else show error message on same page
    errors=[]
    if password != confirm_password:
        errors.append("Password and Confirm password do not match")
        return templates.TemplateResponse("register.html", {"request": request, "errors": errors})
    #validate if the email is already registered
    user_exists=db.query(User).filter(User.email == email).first()
    if user_exists:
        errors.append("Email already registered")
        return templates.TemplateResponse("register.html", {"request": request, "errors": errors})
    
    
    #persist the user data with the hashed password
    hashed_password=get_password_hash(password)
    new_user=User(name=name,hashed_password=hashed_password,email=email,role=role)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return RedirectResponse(url="/auth/login", status_code=303)


@router.get("/login")
def login_user(request:Request):
    #load the login.html file
    try:
        return templates.TemplateResponse("login.html", {"request": request})

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="HTML file not found")

    
@router.post("/login")
def login_user_post(
   # request: Request, email: str = Form(...), password: str = Form(...,min_length=8, max_length=20),db:Session=Depends(get_db)
   form_data:OAuth2PasswordRequestForm=Depends(OAuth2PasswordRequestForm),
   db:Session=Depends(get_db),

):
    # # 1. verify the password
    
    # errors = []
    # user=db.query(User).filter(User.email== email).first()
    # if not user:
    #     errors.append("Not a registered user. Pls register")
    #     return templates.TemplateResponse("login.html", {"request": request, "errors": errors})
    # if not verify_password(password, user.hashed_password):
    #     errors.append("Email and Password do not match")
    #     return templates.TemplateResponse("login.html", {"request": request, "errors": errors})
    
    # # 3. generate token


    # response = RedirectResponse(url="/books", status_code=303)
    # return response
    user=db.query(User).filter(User.email == form_data.username).first()
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect username")
    if not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Email and Password do not match")
    user_scopes=get_scopes_for_role(user.role)
    # 3. generate token
    access_token=create_access_token(data={"sub":user.email,"scopes":user_scopes})
    return {
        "access_token":access_token,"token_type":"bearer"
    }


    
     
    
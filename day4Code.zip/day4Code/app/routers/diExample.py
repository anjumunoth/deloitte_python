from datetime import date
from fastapi import APIRouter, Depends
from app.dependencies.bookDependencies import validate_genre, validate_isbn, FilterParamClass, SortFieldParamClass

from typing import Annotated, List, Literal
from app.db.booksData import books 
from app.models.bookModel import Books, GenreCategory
from fastapi import HTTPException, Query, Path, Body    

router = APIRouter(
    tags=["diExample"],
    responses={404: {"description": "Not found"}},
)


@router.delete("/{isbn}")
def delete_book(
    isbn:str=Depends(validate_isbn)
):     
    #delete book with given isbn
    for index, book in enumerate(books):
        if book.isbn == isbn:
            del books[index]
            return {"detail": f"Book with {isbn} deleted successfully"}
    raise HTTPException(
        status_code = 404,
        detail = f"Book with {isbn} not found"
    )    

#How does DI work
#1. Client makes a delete request to the endpoint /{isbn} with an isbn value.
#2. FastAPI sees that the delete_book function has a dependency on validate_isbn for the isbn parameter.
#3. FastAPI calls the validate_isbn function with the provided isbn value.
#4. If validate_isbn raises an HTTPException, FastAPI returns that error response to the client.
#5. If validate_isbn returns a valid isbn, FastAPI passes that value to the delete_book function.
#6. The delete_book function executes its logic to delete the book and returns the appropriate response.
#7. FastAPI sends the final response back to the client.


@router.put("/{searchIsbn}")
def update_book(
    newPrice: Annotated[int,Body(gt=0) ] ,
    searchIsbn:str= Depends(validate_isbn),):
        for book in books:
            if book.isbn == searchIsbn:
                book.price = newPrice
                return book
        raise HTTPException(status_code=404, detail=f"Book not found with ISBN {searchIsbn}")

@router.get("/")
def get_books():
    return books

@router.get("/genre/", response_model=List[Books])
def get_filtered_books(
    genre :str=Depends(validate_genre)
):
    """
    Docstring for get_filtered_books
    
    :param genre: Description
    :type genre: Annotated[GenreCategory, Query(title="Genre books")]
    will throw 422 error if genre not in predefined set
    :return: List of books filtered by genre
    will throw 404 error if no books found for the genre
    """
    filtered_books = [book for book in books if book.genre.lower() == genre.lower()]
    
    if not filtered_books: 
        raise HTTPException(status_code=404, detail=f"No books found for genre {genre}")
    
    return filtered_books


@router.get("/filter/", response_model=List[Books])
def filter_books(
    commons:FilterParamClass=Depends(FilterParamClass)
):
    filtered_books = books
    price=commons.price
    author=commons.author
    dateOfPublication=commons.dateOfPublication
    
    if price is not None:
        filtered_books = [book for book in filtered_books if book.price <= price]

    if author is not None:
        filtered_books = [
            book
            for book in filtered_books
            if any(author.lower() in a.name.lower() for a in book.authors)
        ]

    if dateOfPublication is not None:
        filtered_books = [
            book
            for book in filtered_books
            if book.dateOfPublication == dateOfPublication
        ]

    if not filtered_books:
        raise HTTPException(
            status_code=404, detail="No books found matching the criteria"
        )

    return filtered_books
        

@router.get("/sort/")
def sort_books(
    sortField: str = Depends(SortFieldParamClass(),use_cache=False),
    sortOrder: str = Query(Literal["asc","desc"], description="Sort order: asc or desc")
):
    # Get all possible attribute names from the Pydantic model
    valid_fields = Books.model_fields.keys()
    if sortField not in valid_fields:
        raise HTTPException(status_code=400, detail=f"Invalid sortField: {sortField}")

    reverse = sortOrder.lower() == "desc"

    try:
        sorted_books = sorted(
            books,
            key=lambda book: getattr(book, sortField) if getattr(book, sortField) is not None else "",
            reverse=reverse
        )
    except Exception:
        raise HTTPException(status_code=400, detail="Sorting failed due to invalid field or un-sortable values")

    if not sorted_books:
        raise HTTPException(status_code=404, detail="No books to sort")
    return sorted_books
    
 
@router.get("/{isbn}",response_model=Books)
def get_book_by_isbn(
    isbn: str = Depends(validate_isbn),
):
    
    for book in books:
        if book.isbn == isbn:
            return book
    raise HTTPException(status_code=404, detail="Book not found")

@router.post("/", response_model=Books, status_code=201)
def add_book(book: Books):
    # Check if a book with the same ISBN already exists
    for existing_book in books:
        if existing_book.isbn == book.isbn:
            raise HTTPException(status_code=400, detail="Book with this ISBN already exists")
    
    books.append(book)
    return book 







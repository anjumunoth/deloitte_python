from fastapi import APIRouter, Security

from app.dependencies.apiDependencies import get_current_user
from app.models.userModels import User


router = APIRouter(
    
    tags=["items"],
    responses={404: {"description": "Not found"}},
)

items=[{"item_id":101,"item_name":"iphone","price":7687},
       {"item_id":102,"item_name":"google pixel","price":17687},
       {"item_id":103,"item_name":"samsung fold5","price":79687},
       {"item_id":104,"item_name":"one plus","price":76807}
       ]

#protected route with the permission item:read 
@router.get("/")
def getAllItems(current_user:User=Security(get_current_user,scopes=["items:read"])):
    return items

#protected route with the permission item:write(Admin)
@router.post("/")
def addItem(current_user:User=Security(get_current_user,scopes=["items:write"]),
            item={}):
    items.append(item)
    return {item}




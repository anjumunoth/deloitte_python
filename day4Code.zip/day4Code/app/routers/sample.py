from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.responses import FileResponse, StreamingResponse, RedirectResponse, Response
from pathlib import Path 
    

router= APIRouter(
    tags=["sample"],    
    responses={404: {"description":"Not found"}},
)

@router.get("/getHtmlFile")
def get_html_file():
    html_content="""
    <html>
        <head>
            <title>Sample HTML</title>
        </head>
        <body>
            <h1>This is a sample HTML file served by FastAPI</h1>
            <p>Hello, welcome to the FastAPI application!</p>
        </body>
    </html>
    """
    return HTMLResponse(content=html_content, status_code=200)

#return an image
@router.get("/getImageAsBinary")
async def get_image_file():
    # image_path="app/static/sample_image.jpg"
    image_path=Path(__file__).parent.parent / "static" / "sample_image.jpg"
    try:
        with open(image_path, "rb") as image_file:
            image_data=image_file.read()
        return HTMLResponse(content=image_data, media_type="image/jpeg", status_code=200)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Image file not found")
    
#return a image file which can be downloaded
@router.get("/getImageAsFile")
def get_image_as_file():
    image_path=Path(__file__).parent.parent / "static" / "sample_image.jpg"
    return FileResponse(path=image_path, media_type="image/jpeg", filename="sample_image.jpg")


#return a pdf file which can be downloaded
@router.get("/getPdfAsFile")
def get_pdf_as_file():
    try:   
        pdf_path=Path(__file__).parent.parent / "static" / "sara.pdf"
        return FileResponse(path=pdf_path, media_type="application/pdf", filename="sara.pdf",)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="PDF file not found")


#return a video using file response
@router.get("/getVideoAsFile")
def get_video_as_file():    
    try:
        video_path=Path(__file__).parent.parent / "static" / "sample_video.mp4"
        return FileResponse(path=video_path, media_type="video/mp4", filename="sample_video.mp4",)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Video file not found")
    
#return a video as streaming response
@router.get("/getVideoAsStream")
def get_video_as_stream():  
    try:
        video_path=Path(__file__).parent.parent / "static" / "sample_video.mp4"
        video_file=open(video_path, mode="rb") 
        return StreamingResponse(video_file, media_type="video/mp4")
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Video file not found")

#return a redirect response
@router.get("/redirectToFastapi")
def redirect_to_fastapi():
    return RedirectResponse(url="https://fastapi.tiangolo.com/",status_code=301)

@router.get("/redirectToBooks")
def redirect_to_fastapi():
    #301 is permanent redirect
    return RedirectResponse(url="/books", status_code=301)

#setup response header information
@router.get("/customHeaderResponse")
def custom_header_response(response:Response):
    response.headers["X-Custom-Header"]="CustomHeaderValue"
    response.headers["X-Powered-By"]="FastAPI"

    return {"message":"Custom headers set in the response"}

